<?php

global $_LANGMAIL;
$_LANGMAIL = array();
$_LANGMAIL['Welcome!'] = 'Bienvenido a LOONES!';
$_LANGMAIL['Package in transit'] = '';
$_LANGMAIL['Message from a seller'] = '';
$_LANGMAIL['Your seller account approved!'] = 'Su cuenta de Productor ha sido aprobada';
$_LANGMAIL['Fund request from a seller'] = '';
$_LANGMAIL['New Order'] = '';
$_LANGMAIL['New product approval request'] = '';
$_LANGMAIL['Your seller account'] = 'Alta de su cuenta de Productor';
$_LANGMAIL['A new seller account has been added'] = 'Una nueva cuenta de Productor ha sido creada';
$_LANGMAIL['Order Return Request'] = '';
$_LANGMAIL['Product Approved'] = '';
$_LANGMAIL['Product Disapproved'] = '';
$_LANGMAIL['You can access your seller account by: login to front office, go to my seller account then click link to your seller account at back office.'] = 'Puede acceder a su cuenta de productor desde "iniciar sesion" del panel principal';

